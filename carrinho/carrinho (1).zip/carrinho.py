print("Bem Vindo ao carrinho")
matriz = []
total = 0

def pagamento():
            global total
            print('')
            print('Preço das compras: R$', total)
            print("FORMAS DE PAGAMENTO")
            print("[1] Dinheiro")
            print("[2] Cartão")
            opção = int(input('Escolha uma opção: '))

            if opção == 1:
                while (total != 0):
                    print("Total: R$",total)
                    pagar = float(input("Quanto deseja pagar?"))
                    
                    if total - pagar == 0:
                        print("Compra Realizada.")
                        break
                    elif total < pagar:
                        total = total - pagar
                        print("Esse é seu troco: R$",total * -1)
                        break
                    elif total > pagar:
                        total = total - pagar
                        print("vai de novo")

            elif opção == 2:
                print(total, "Aqui Acabou")

def menu():
    print("1- Adicionar produto" + "\n" + "2- Total da compra" + "\n" + "3- Forma de pagamento")
    escolha = int(input("O que deseja fazer?" + "\n"))

    if escolha == 1:
        def adicionar():
            global total
            global matriz
            for colunas in range(1):
                linhas =  []
                for valor in range(0, 1, 1):
                    produto = input("Nome do produto \n")
                    preco = float(input("Preço do produto \n"))
                    qnt = float(input("Quantidade de Produtos \n"))
                    linhas.insert(valor, [produto, preco, qnt])
                    total = total + preco * qnt
                    break   
            matriz.append(linhas)

            for linhas in matriz:
                print(' '.join(map(str, linhas)))
            menu()
        adicionar()    
    if escolha == 2:
        for x in matriz:
            print(x)
        print("O total da compra está em: R$",total,"Deseja continuar comprando? \n [1]Sim [2]Não")
        acao = input("")
        if acao == "1":
            menu()
        else:
            pagamento()
        menu()
    if escolha == 3:
        pagamento()
menu()

